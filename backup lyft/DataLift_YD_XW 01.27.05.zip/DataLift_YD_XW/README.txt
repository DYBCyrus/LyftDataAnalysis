/**
 * Team Name: DataLift
 * Members: Yaobang Deng, Xinran Wang
 */

 Files:
 - LyftDataAnalysisModel.ipynb contains the result of data cleaning
 and the result of modeling
 - LyftDataAnalysisStats.ipynb contains the result of data cleaning
 and the result of statistical analysis.
 - Writeup is saved as a PDF file
 - images directory contains all generated images through analysis.
